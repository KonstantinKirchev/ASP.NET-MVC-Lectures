﻿namespace Twitter.Models.Enumerations
{
    public enum NotificationType
    {
        Retweet,

        FavouriteTweet,

        NewFollower
    }
}