﻿using System.ComponentModel.DataAnnotations;

namespace Snigger.Models
{
    public class Snicker
    {
        [Key]
        public int Id { get; set; }
    }
}
