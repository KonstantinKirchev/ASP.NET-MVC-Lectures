﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LaptopStore.App.Models
{
    public class Address
    {
        public string StreetName { get; set; }

        public int StreetNumber { get; set; }
    }
}