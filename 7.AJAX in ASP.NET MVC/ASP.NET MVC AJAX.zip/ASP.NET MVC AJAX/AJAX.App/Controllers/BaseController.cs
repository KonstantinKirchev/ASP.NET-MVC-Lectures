﻿namespace AJAX.App.Controllers
{
    using System.Web.Mvc;

    using AJAX.Data.UnitOfWork;

    public class BaseController : Controller
    {
        public BaseController()
            : this(new AjaxData())
        {
        }

        public BaseController(IAjaxData data)
        {
            this.Data = data;
        }

        protected IAjaxData Data { get; }
    }
}