﻿namespace AJAX.Data
{
    using System.Data.Entity;

    using Models;

    public interface IAjaxContext
    {
        IDbSet<Town> Towns { get; }
    }
}
