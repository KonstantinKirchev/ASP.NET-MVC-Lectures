﻿namespace AJAX.Models
{
    public enum StatusType
    {
        Single,
        Married
    }
}
