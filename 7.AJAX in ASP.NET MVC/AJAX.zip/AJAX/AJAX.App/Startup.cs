﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(AJAX.App.Startup))]
namespace AJAX.App
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
