﻿namespace AJAX.Data.UnitOfWork
{
    using AJAX.Data.Repositories;
    using AJAX.Models;

    public interface IAjaxData
    {
        IRepository<User> Users { get; }

        IRepository<Town> Towns { get; }

        void SaveChanges();
    }
}
