﻿namespace Bookmarks.Common.Mappings
{
    using System;

    internal class TypesMap
    {
        public Type Source { get; set; }

        public Type Destination { get; set; }
    }
}
