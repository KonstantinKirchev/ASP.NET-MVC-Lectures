﻿namespace Bookmarks.Common.Mappings
{
    public interface IMapFrom<T>
    {
    }
}
