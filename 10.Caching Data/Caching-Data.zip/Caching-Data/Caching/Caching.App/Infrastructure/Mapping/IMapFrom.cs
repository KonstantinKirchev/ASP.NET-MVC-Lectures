﻿namespace Caching.App.Infrastructure.Mapping
{
    public interface IMapFrom<T>
    {
    }
}